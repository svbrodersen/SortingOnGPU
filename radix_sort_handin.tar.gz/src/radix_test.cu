#include "../utils/utils.cuh"
#include "sort.cuh"

// C++ Standard Library Headers
#include <cstdint>
#include <iomanip>  // For std::setw, std::left
#include <iostream> // For std::cout, std::cerr, std::endl
#include <limits>   // For std::numeric_limits
#include <map>      // For std::map (element preservation and results)
#include <random>
#include <string> // For std::string
#include <tuple>  // For std::tuple (to list types)
#include <type_traits>
#include <utility> // For std::apply
#include <vector>  // For std::vector (replaces malloc/free)

#include <cuda_runtime.h>

const uint32_t Q = 22;
const uint32_t B = 256;
const uint32_t lgH = 8;
const uint32_t TILE_SIZE = 32;

template <typename T> struct TypeName {
  static const char *value;
};
template <> const char *TypeName<uint32_t>::value = "uint32_t";
template <> const char *TypeName<int32_t>::value = "int32_t";
template <> const char *TypeName<int64_t>::value = "int64_t";
template <> const char *TypeName<float>::value = "float";
template <> const char *TypeName<double>::value = "double";
template <> const char *TypeName<uint64_t>::value = "uint64_t";
template <> const char *TypeName<uint16_t>::value = "uint16_t";
template <> const char *TypeName<uint8_t>::value = "uint8_t";
template <typename T> const char *TypeName<T>::value = "unknown"; // Fallback

template <typename T>
void printArray(T *inp_vals, uint32_t N, const char *name) {
  std::cout << name << "[:" << N << "] = [";
  for (uint32_t i = 0; i < N; i++) {
    std::cout << inp_vals[i];
    if (i < N - 1) {
      std::cout << ", ";
    }
  }
  std::cout << "]\n";
}

/**
 * @brief Runs a single test case for a given array size N.
 * @param N The number of elements to sort.
 * @return true if the test passed, false otherwise.
 */
template <typename T> bool runTest(uint32_t N) {
  // Determine the type name for clearer output
  const char *type_name = TypeName<T>::value;

  // 1. Define constants (same for both types, assuming 32-bit key)
  const uint32_t mem_size = N * sizeof(T);

  bool success = true;

  // 2. Allocate host memory for type T
  T *inp_vals = (T *)malloc(mem_size);
  T *inp_vals_copy = (T *)malloc(mem_size);
  T *out_vals = (T *)malloc(mem_size);

  if (!inp_vals || !inp_vals_copy || !out_vals) {
    printf("ERROR: Host memory allocation failed!\n");
    if (inp_vals)
      free(inp_vals);
    if (inp_vals_copy)
      free(inp_vals_copy);
    if (out_vals)
      free(out_vals);
    return false;
  }

  // 3. Fill with random data
  for (uint32_t i = 0; i < N; i++) {
    // In reverse order,
    inp_vals[i] = randomValue<T>();
  }

  // Add some edge cases based on the type
  if (N > 10) {
    inp_vals[0] = 0;
    inp_vals[2] = 1;
    inp_vals[4] = 100;
    inp_vals[5] = 100;

    if constexpr (std::is_unsigned_v<T>) {
      inp_vals[1] = std::numeric_limits<T>::max();
      inp_vals[3] = std::numeric_limits<T>::max();
    } else if constexpr (std::is_signed_v<T>) {
      inp_vals[1] = std::numeric_limits<T>::max();
      inp_vals[3] = std::numeric_limits<T>::max();
      // Add a negative number
      if (N > 6)
        inp_vals[6] = -1;
      if (N > 7)
        inp_vals[7] = -100;
    } else if constexpr (std::is_same_v<T, float_t> ||
                         std::is_same_v<T, double>) {
      inp_vals[0] = 0;
      inp_vals[1] = -0.0;
      inp_vals[2] = std::numeric_limits<T>::infinity();
      inp_vals[3] = -std::numeric_limits<T>::infinity();
      inp_vals[4] = std::numeric_limits<T>::lowest();
      inp_vals[5] = std::numeric_limits<T>::max();
      inp_vals[6] = static_cast<T>(N) * 0.123;
      inp_vals[7] = static_cast<T>(-N) * 0.456;
    }
  }

  // 4. Create copy for verification
  memcpy(inp_vals_copy, inp_vals, mem_size);

  // 5. Run GPU Radix Sort (using template parameter T)
  if (radixSort<T, Q, B, lgH, TILE_SIZE>(inp_vals, out_vals, N) != 0) {
    printf("ERROR: radixSort function returned non-zero exit code.\n");
    success = false;
  }

  // 6. Verification 1: Check if sorted
  if (success) {
    validateZ<T>(out_vals, N);
  }

  // 7. Verification 2: Element Preservation
  if (success) {
    if (!checkElementPreservation(inp_vals_copy, out_vals, N)) {
      printf("ERROR: Element preservation failed! Output is not a permutation "
             "of the input.\n");
      success = false;
    }
  }

  // 8. Cleanup
  free(inp_vals);
  free(inp_vals_copy);
  free(out_vals);

  printf("--- Test for N = %u, Type = %s %s ---\n", N, type_name,
         success ? "PASSED" : "FAILED");
  return success;
}

template <typename T> int runAllTests(int *test_sizes, int N) {
  // Define a set of test sizes
  int tests_passed = 0;

  for (int i = 0; i < N; i++) {
    if (runTest<T>(test_sizes[i])) {
      tests_passed++;
    }
  }

  return tests_passed;
}

int main() {
  initializeDeviceOnce();
  int N_sizes = 6;
  int test_sizes[] = {10, 100, 1024, 5000, 10000, 1000000};

  int total_tests = 0;
  int total_passed = 0;

  using TestTypes = std::tuple<uint32_t, int32_t, int64_t, float, double,
                               uint64_t, uint16_t, uint8_t>;
  std::map<std::string, int> results;

  std::apply(
      [&](auto... type) {
        // This C++17 fold expression expands to:
        // results["uint32_t"] = runAllTests<uint32_t>(...);
        // results["int32_t"]  = runAllTests<int32_t>(...);
        // ...and so on for every type in TestTypes
        (..., (results[TypeName<decltype(type)>::value] =
                   runAllTests<decltype(type)>(test_sizes, N_sizes)));
      },
      TestTypes{});

  total_passed = 0;
  total_tests = 0;

  std::cout << "\n\n====== FINAL TEST SUMMARY ======\n";
  for (const auto &[type_name, passed_count] : results) {
    std::cout << std::left << std::setw(12) << (type_name + " tests:")
              << " Passed " << passed_count << "/" << N_sizes << "\n";
    total_passed += passed_count;
    total_tests += N_sizes;
  }

  printf("**Total Tests: Passed %d out of %d tests.**\n", total_passed,
         total_tests);
  printf("====================================================\n");

  // Return 0 if all tests passed, 1 otherwise
  return (total_passed == total_tests) ? 0 : 1;
}
